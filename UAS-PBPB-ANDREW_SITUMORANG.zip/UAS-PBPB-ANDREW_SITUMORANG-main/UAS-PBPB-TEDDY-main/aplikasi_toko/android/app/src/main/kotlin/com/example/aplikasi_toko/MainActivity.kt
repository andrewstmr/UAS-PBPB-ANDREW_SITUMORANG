package com.example.aplikasi_toko

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
